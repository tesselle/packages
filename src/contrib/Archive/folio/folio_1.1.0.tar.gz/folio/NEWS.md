# folio 1.1.0

* Add the `verre` dataset (chemical data).
* Add the `ngrip2004` dataset (palaeoclimates).
* Add the `stratigraphy` dataset (chronological data).

# folio 1.0.0

* Add the `kommos` dataset (chemical data).
* Add the `chevelon` dataset (count data).
* Add the `law2006` and `epica2008` datasets (palaeoclimates).
* Add the `nydal1996` dataset (isotopic data).
* Add the `arnold1949` dataset (historical radiocarbon dates; "curve of knows").
* Remove the `altamira` dataset.

# folio 0.1.0

* Add the `altamira`, `birds`, `boves`, `compiegne`, `merzbach`, `mississippi` and `zuni` datasets (count data).
* Add the `intcal09`, `intcal13` and `intcal20` datasets (radiocarbon calibration curves).
* Add the `lisiecki2005` and `spratt2016` datasets (isotopic data).
